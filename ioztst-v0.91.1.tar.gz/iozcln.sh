#!/bin/bash

##########
#
# Project     :
# Started     :
# Author      :
# Module      :
# Description :
#
##########

# start of code here
clear

function progbar {
  local duration=${1}

    already_done() { for ((done=0; done<$elapsed; done++)); do printf "▇"; done }
    remaining() { for ((remain=$elapsed; remain<$duration; remain++)); do printf " "; done }
    percentage() { printf "| %s%%" $(( (($elapsed)*100)/($duration)*100/100 )); }
    clean_line() { printf "\r"; }

  for (( elapsed=1; elapsed<=$duration; elapsed++ )); do
      already_done; remaining; percentage
      sleep 1
      clean_line
  done
  clean_line
}

tmpextract=$HOME/tempiozextract
configdir=$HOME/.config/ioztst
#source $HOME/.config/ioztst/iozconf
if [ -f $HOME/iozconf ]; then
   source $HOME/iozconf
else
   source $HOME/.config/ioztst/iozconf
fi

# Dire warning to potential users
echo
echo " Standard disclaimer, you know what it is."
echo " If you want to be able to delete the ioztst stuff, this has all the info embedded and"
echo " the capability to do it"
echo
echo "   It's important that you understand what happens during the deletion process."
echo "   There are Four separate steps, each one is outlined below:"
echo
echo "  1) The config dir -> $HOME/.config/ioztst"
echo "     When you get past the 10 second warning, the top line will name a directory"
echo "     The next line will prompt you to decide on deleting the directory above"
echo "     Between the [square] brackets you should see an EXACT duplicate of the top line"
echo "     If the two lines do NOT agree, STOP and exit by using <Ctrl><C>."
echo "     Something has gone wrong and if you attempt to delete anything you may damage"
echo "     your system."
echo
echo "  2) The dir where the tar.gz file has it's contents extracted -> $HOME/tempiozextract"
echo "     The same caveats apply to this and each succeding delete option"
echo
echo "  3) The test directory -> ${basedir}/tmptest where the test scripts"
echo "     run and the data files are created (and deleted) by iozone during the testing"
echo
echo "  4) The final thing to be deleted -> $HOME/bin/ioztst.sh  This is the script"
echo "     that runs the testing process and calls iozone to run the test"
echo
echo " There are two dirs I will leave to you to cleanup as the [$HOME/Downloads] dir"
echo " contains the actual tar.gz archives and the [${resultdir}] "
echo " holds any files produced after an iozone run. These files may be useful to you so"
echo " this script won't touch them"
echo
read -p "  Do you want to continue (y/n): " ans
answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
if [ "${answer}" == "y" ]; then
   echo
   echo "  > You can abort at any time within the next 10 seconds by typing <Ctrl><C> :"
   echo
   progbar 10
else
   exit 1
fi
# cleanup
clear
echo
echo " Just kidding.  If you answer with anything but [Y|y] nothing will be deleted"
echo " Pressing <Enter> is equivalent to answering NO"
echo
echo
if [ -d ${configdir} ]; then
   cp ${configdir}/iozconf $HOME/iozconf
   source $HOME/iozconf
   ls  -Ad ${configdir}
   echo
   echo "   --- Config dir ---"
   read -p "  Do you want to delete the dir: [${configdir}] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting directory"
      echo
      rm -R  -d ${configdir}
   else
      echo
      echo " Not deleting [${configdir}]"
      echo
   fi
fi

if [ -d $tmpextract ]; then
   ls -Ad ${tmpextract}
   echo
   echo "   --- Temp Extract dir ---"
   read -p "  Do you want to delete the dir: [${tmpextract}] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting directory"
      echo
      rm -R ${tmpextract}
   else
      echo
      echo " Not deleting [$HOME/tempiozextract]"
      echo
   fi
fi

if [ -d "${basedir}"/tmptest ]; then
   ls -Ad "${basedir}"/tmptest
   echo
   echo "   --- Temporary test dir ---"
   read -p "  Do you want to delete the dir: [${basedir}/tmptest] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting directory"
      echo
      rm -R "${basedir}"/tmptest
   else
      echo
      echo " Not deleting [${basedir}/tmptest]"
      echo
   fi
fi

if [ -f $HOME/bin/ioztst.sh ]; then
   ls -A $HOME/bin/ioztst.sh
   echo
   echo "   --- Ioztst.sh: the script that runs the tests ---"
   read -p "  Do you want to delete the file: [$HOME/bin/ioztst.sh] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting file"
      echo
      rm $HOME/bin/ioztst.sh
   else
      echo
      echo " Not deleting [$HOME/bin/ioztst.sh]"
      echo
   fi
fi

# EOF
