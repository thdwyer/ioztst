#!/bin/bash

##########
#
# Project     :
# Started     :
# Author      :
# Module      :
# Description :
#
##########

# start of code here
clear

#Timer function
timebar() {
    local w=50 p=$1;  shift
    # create a string of spaces, then change them to dots
#   printf -v dots "%*s" "$(( $p*$w/100 ))" ""; dots=${dots// /.};
    printf -v dots "%*s" "$(( $p*$w/100 ))" ""; dots=${dots// /=};
    # print those dots on a fixed-width space plus the percentage etc.
    #printf "\r\e[K|%-*s| %3d %% %s" "$w" "$dots" "$p" "$*";
    printf "\r\e[K           [%-*s] %3d  %s" "$w" "$dots" "$y" "$*";
}

tmpextract=$HOME/tempiozextract
configdir=$HOME/.config/ioztst
#source $HOME/.config/ioztst/iozconf
if [ -f $HOME/iozconf ]; then
   source $HOME/iozconf
else
   source $HOME/.config/ioztst/iozconf
fi

# Dire warning to potential users
echo
echo " Standard disclaimer, you know what it is."
echo " If you want to be able to delete the ioztst stuff, this has all the info embedded and"
echo " the capability to do it"
echo
echo "   It's important that you understand what happens during the deletion process."
echo "   There are Five separate steps, each one is outlined below:"
echo
echo "  1) The config dir -> [$HOME/.config/ioztst]."
echo "     When you get past the 10 second warning, the top line will name a directory."
echo "     The next line will prompt you to decide on deleting the directory above."
echo
echo "     Between the [square] brackets you should see an EXACT duplicate of the top line."
echo "     If the two lines do NOT agree exactly, STOP and exit by using <Ctrl><C>."
echo
echo "     Something may have gone wrong and if you attempt to delete anything, you may"
echo "     damage your system."
echo
echo "  2) The dir the tar.gz file is extracted to -> [$HOME/tempiozextract]"
echo "     The same caveats apply to this and each succeding delete option."
echo
echo "  3) In the -> [$HOME/bin] dir the Install.sh file will be deleted. You should"
echo "     delete this file because a newer download may have a later version."
echo
echo "  4) The executable file to be deleted -> [$HOME/bin/ioztst.sh]  This is the script"
echo "     that runs the testing process and calls iozone to run the test. You should"
echo "     delete this file because a newer download may have a later version."
echo
echo "  5) The test directory -> [${basedir}/tmptest] where the test scripts"
echo "     run and the data files are created (and deleted) by iozone during the testing"
echo "     <<< Pay attention to warning in this delete operation.  If you have ANY doubts"
echo "     <<< about the directory path and the prompt string matching, abort with <Ctrl><C>."
echo
echo " There are two dirs I will leave to you to cleanup as the [$HOME/Downloads] dir"
echo " contains the actual tar.gz archives and the [${resultdir}] "
echo " holds any files produced after an iozone run. These files may be useful to you so"
echo " this script won't touch them.  Other files that won't be deleted are:"
echo " -> [$HOME/bin/report.pl] used to produce the gnuplot graphs and:"
echo " -> [$HOME/bin/iozcln.sh] the file you are using to uninstall and cleanup now)"
echo
read -p "  Do you want to continue (y/n): " ans
answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
if [ "${answer}" == "y" ]; then
   echo
   echo "  > You can abort at any time within the next 10 seconds by typing <Ctrl><C> :"
   echo

   # timer loop
   for x in {1..100} ; do
      y=$(( $x/10 ))
      timebar "$x"
      sleep 0.1
   done ; echo
else
   exit 1
fi
# cleanup
clear
echo
echo " Just kidding.  If you answer with anything but [Y|y] nothing will be deleted"
echo
echo " Pressing <Enter> is equivalent to answering NO"
echo
echo " In the parts that mattered I have used as much of the absolute paths to files"
echo " and directories as is possible. I've used \$HOME because there is no way to"
echo " otherwise determine your username [$USER].  The only directory path where I"
echo " had to use the variable name is \$basedir: [$basedir]"
echo " because that could be almost anywhere including a network mounted drive."

if [ -d $HOME/.config/ioztst ]; then
   cp $HOME/.config/ioztst/iozconf $HOME/iozconf
   source $HOME/iozconf
   ConfD=$(ls  -Ad $HOME/.config/ioztst)
   echo
   echo "   --- Config dir ---"
   echo "                                  ${ConfD}"
   read -p "  Do you want to delete the dir: [${configdir}] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting directory"
      rm -R  -d $HOME/.config/ioztst
   else
      echo
      echo " Not deleting [${configdir}]"
   fi
fi

if [ -d $HOME/tempiozextract ]; then
   TempX=$(ls -Ad $HOME/tempiozextract)
   echo
   echo "   --- Temp Extract dir ---"
   echo "                                  ${TempX}"
   read -p "  Do you want to delete the dir: [${tmpextract}] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting directory"
      rm -R $HOME/tempiozextract}
   else
      echo
      echo " Not deleting [$HOME/tempiozextract]"
   fi
fi

if [ -f $HOME/bin/Install.sh ]; then
   InstF=$(ls -A $HOME/bin/Install.sh)
   echo
   echo "   --- Install.sh: the script that installs the ioztst package ---"
   echo "                                   ${InstF}"
   read -p "  Do you want to delete the file: [$HOME/bin/Install.sh] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting file"
      rm $HOME/bin/Install.sh
   else
      echo
      echo " Not deleting [$HOME/bin/Install.sh]"
   fi
fi

if [ -f $HOME/bin/ioztst.sh ]; then
   IozF=$(ls -A $HOME/bin/ioztst.sh)
   echo
   echo "   --- Ioztst.sh: the script that runs the tests ---"
   echo "                                   ${IozF}"
   read -p "  Do you want to delete the file: [$HOME/bin/ioztst.sh] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      echo "  deleting file"
      rm $HOME/bin/ioztst.sh
   else
      echo
      echo " Not deleting [$HOME/bin/ioztst.sh]"
   fi
fi

if [ -d "${basedir}"/tmptest ]; then
   echo " <<< This is the \$basedir [$basedir] you need to be sure about."
   echo " >>> Pay attention to the dir listing (directly below) and the prompt"
   echo " >>> string [${basedir}/tmptest].  They should agree exactly!"
   BaseD=$(ls -Ad "${basedir}"/tmptest)
   echo
   echo "   --- Temporary test dir ---"
   echo "                                  ${BaseD}"
   read -p "  Do you want to delete the dir: [${basedir}/tmptest] (y/n): " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      echo
      # last attempt to ensure the target is correct
      cd "${basedir}"
      tmpexist=$(ls -Ad tmptest)
      if [ -z ${tmpexist} ]; then
         echo "directory not present - Aborting"
      else
         echo "  deleting directory"
         rm -R "${basedir}"/tmptest
      fi
   else
      echo
      echo " Not deleting [${basedir}/tmptest]"

   fi
   echo
fi
# EOF
