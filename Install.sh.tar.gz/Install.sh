#!/bin/bash

##########
#
# Project     : iozone shell script wrapper install script
# Version     : ver 0.3.1
# Started     : Wed 31 Jul 2024
# Author      : Terry Dwyer
# Module      :
# Purpose     : Install and setup the iozone utility.
#             :
#             :
# Description :
#
##########

# Next, provide the feature that allows complete removal of
# The ioztst script and all the directories and files that would
# be otherwise left behind.. It would be nice to use acceptable
# option switches like '-u' for uninstall.

# start of code here

###########################################################################
# Do not edit anything in this script unless you know what you are doing. #
# changing the wrong variables could result in loss of your data.         #
###########################################################################

clear

dontclear=true
enableiozone=YES
basedir=""

testdir=tmptest
targetdir=$basedir/$testdir

#  Values needed:
# Temporary dir to extract the files from the archive
tmpextract=$HOME/tempiozextract
# Hopefully the downloaded package is in the default Downloads directory
downloaddir=$HOME/Downloads
# This takes into account version changes
tarfile=`ls ${downloaddir}/ioztst* | awk -F"/" '{print $NF}'`
# Where the results from the test and the user guide go
docdir=$HOME/Documents
#  Install dir for ioztst.sh
scriptdir=$HOME/bin
# full path and filename of the ioztst.sh
scriptfile=$scriptdir/ioztst.sh
#  Dir to store config file and scripts to run iozone
configbasedir=$HOME/.config
#  Config basedir
configdir=$HOME/.config/ioztst
# Config file
configfile=iozconf
# Is there a config file already installed
if [ -f ${configdir}/${configfile} ]; then
   # I don't think this is used
   confinst=`ls "${configdir}/${configfile}" | awk -F"/" '{print $NF}'`
   # echo "Config file present: ${confinst}" ; sleep 2
else
   confinst=""
fi
# The dummy basedir in the source conf file
dummyconfstr="basedir=EditThisString"
#   Dir to save results files in
#  Throughput definition fies
Tputdir=$HOME/.config/ioztst/Run
#  Auto definition files
Autodir=$HOME/.config/ioztst/Default

# Set a few things up
shopt -s nullglob
# Error trapping
#set -Eeou pipefail

# Get the name of the running script
iam=$(basename $(readlink -nf $0))
# Get the version of this script from the header
version=`grep "^# Version" ${iam} | awk '{print $NF}'`

export TIME="\t%E real,\t%U user,\t%S sys"
timecmd=/usr/bin/time
# Replaces all spaces in the returned date value with underscores
datevar=`date | sed '{s/ /_/g}'`
echo

# Define any necessary or useful functions:
############################################################
# Help                                                     #
############################################################
function help_menu {
   # Display Help
   echo "  Install / Uninstall script for ioztst script."
   echo
   echo "  Syntax: Install.sh [-u|g|h|v]"
   echo "  options:"
   echo "  u     Completely uninstall ioztst."
   echo "  g     Read User guide"
   echo "  h     Print this Help."
   echo "  v     Print software version and exit."
   echo
}

function uninstall_ioztst {
   echo "  This is where the uninstall stuff starts" ; sleep 2
}

# Is this an upgrade or the ioztst.sh versions the same
function is_this_an_upgrade {
   currentver=`grep "^# Version" "${scriptdir}/ioztst.sh" | awk '{print $NF}'`
   if [ -f ${tmpextract}/${tarfile} ]; then
      newver=`ls ${tmpextract}/${tarfile} | awk -F"/" '{print $NF}' | grep -o "[0-9]\+\.[0-9]\+\.[0-9]"`
   else
      newver=`ls ${downloaddir}/${tarfile} | awk -F"/" '{print $NF}' | grep -o "[0-9]\+\.[0-9]\+\.[0-9]"`
   fi

   if [ "${newver}" != "${currentver}" ]; then
      diffver=true
      echo "  The versions are different: New version: ${newver}  Current ver: ${currentver}"
      # remove the dots from the version numbers making them arithmetically comparable
      # to determine if the new version is an upgade, the same or older
      # Remove theleading zero so it wont be treated as an ottal number
      newnumver=`echo "${newver}" | sed '{s/\.//g}' | sed 's/^0*//'`
      currnumver=`echo "${currentver}" | sed '{s/\.//g}' | sed 's/^0*//'`
      #echo "  New: [$newnumver]  Current: [$currnumver]"
      echo
      if [ ${newnumver} -eq ${currnumver} ]; then
         echo "  The versions are the same.  No change possible"
         changever=false
      elif [[ ${newnumver} -gt ${currnumver} ]]; then
         echo "  An upgrade is possible"
         changever=true
         #echo "  New: [${newnumver}]  Current: [${currnumver}]"
      elif [[ ${newnumver} -lt ${currnumver} ]]; then
         echo "  The downloaded version is older"
         changever=false
         #echo "  New: [${newnumver}]  Current: [${currnumver}]"
      else
         echo "  An error occured.  one of the version numbers is missing or garbled"
         changever=false
         #echo "  New: [${newnumver}]  Current: [${currnumver}]"
      fi
   else
      echo "  Downloaded version: ${newver}   Current ver: ${currentver}"
      echo
      echo "  An upgrade is not possible. The downloaded version"
      echo "  is the same as the installed version"
   fi
}

# Get the new config file and edit the existing basedir into it
function get_host_config {
   if [ -f "${configdir}/${configfile}" ]; then
      # get the basedir variable that has been previouslry configured for this machine
      currentbasedir=`grep ^basedir= "${configdir}/${configfile}"`
      echo "  Current basedir: [${currentbasedir}]" #; sleep 10
      if [ -n "${currentbasedir}" ]; then
         # Get the dummy string without any leading #
         dummypresent=`grep "${dummyconfstr}" "${tmpextract}/${configfile}" | awk -F"#" '{print $NF}'`
         echo "      Dummy entry: [${dummypresent}]  [${dummyconfstr}]"
         if [ "${dummypresent}" == "${dummyconfstr}" ]; then
            echo "  Dummy string in source config file will be replaced with:"
            echo "        ${currentbasedir}"
            # move the original conf file to iozconf.backup
            mv -f "${configdir}/${configfile}" "${configdir}/${configfile}.backup"
            # copy the source conf file to the conf directory
            cp "${tmpextract}/${configfile}" "${configdir}"
            # use sed to edit the dummy string in the new config file
            sed -E -i "s:${dummyconfstr}:${currentbasedir}:" "${configdir}/${configfile}"
         fi
      else
         echo "  Currentbasedir: [${currentbasedir}]" ; sleep 2
      fi
   else
      echo "  No config for this machine yet"; sleep 2
   fi
}

trap 'error_handler $? $LINENO' ERR
function error_handler {
   echo "Error: ($1) occurred on $2"
}

function get_location {
   if [ -z $1 ]; then
      #echo "  Be quiet"
      iamhere=`pwd`
   else
      #echo "  Tell me where I am"
      iamhere=`pwd` ; echo "  PWD: ${iamhere}"
   fi
}

function show_dirs {
   if [ "${dontclear}" != "true" ]; then
      clear
   fi
   echo
   echo " -----------------------------------------------------------------------------------"
   echo " |                   <<< ioztst Install script Ver: ${version} >>>                      |"
   echo " -----------------------------------------------------------------------------------"
   echo " |           Complete list of directory and files from your variables              |"
   echo " -----------------------------------------------------------------------------------"
   echo " |         Description          |  variable name  |         Variable data          |"
   echo " -----------------------------------------------------------------------------------"
   echo "------------------------------------------------------------------------------------"
   echo "                    Run iozone:   enableiozone      ${enableiozone}"
   echo "------------------------------------------------------------------------------------"
   echo "                       Basedir:   basedir           ${basedir}"
   echo "                       Testdir:   testdir           ${testdir}"
   echo "                     Targetdir:   targetdir         ${targetdir}"
   echo "                     Resultdir:   resultdir         ${resultdir}"
   echo "                    Resultfile:   resultfile        ${resultfile}"
   echo "           Screen Capture file:   scrncapfile       ${scrncapfile}"
   echo "                   Result file:   result            ${result}"
   echo "           Screen Capture file:   scrncap           ${scrncap}"
   echo "                   Config file:   configfile        ${configdir}/${configfile}"
   echo " -----------------------------------------------------------------------------------"
   echo "            Saved Test Basedir:   savedtestbasedir  ${savedtestbasedir}"
   echo "            Saved This Run dir:   savedrun          ${savedrun}"
   echo "             Saved Default dir:   saveddefaults     ${saveddefaults}"
   echo "      Saved This Run Auto file:   Asaverunfile      ${Asaverunfile}"
   echo "      Saved This Run Tput file:   Tsaverunfile      ${Tsaverunfile}"
   echo "       Saved Default Auto file:   Asavedefaultfile  ${Asavedefaultfile}"
   echo "       Saved Default Tput file:   Tsavedefaultfile  ${Tsavedefaultfile}"
   echo " -----------------------------------------------------------------------------------"
   echo
   #exit 1
}

############################################################
# Process the input options. Add options as needed.        #
############################################################

# Get the options
while getopts ":ughv" option; do
   case $option in
      u) # Go to uninstall function
         uninstall_ioztst
         exit;;
      g) # Load User Guide
         echo " Load userguide"
         /usr/bin/less ${docdir}/zfstst_user_guide.txt
         exit;;
      h) # display Help
         help_menu
         exit;;
      v) # version
         echo "  <<< ioztst Install/Uninstall script Ver: ${version} >>>"; echo
         exit;;
     \?) # Invalid option
         echo "  <<< Error: Invalid option >>>"; echo
         exit;;
   esac
done

# Start checking for and creating directories where necessary
if [ ! -d "${tmpextract}" ]; then
   echo
   echo " You don't have a ${tmpextract} directory.  Creating now."
   mkdir "${tmpextract}"
   cd "${tmpextract}"
   get_location
   mkdir oldver
fi

# First is the $HOME/bin dir where the script will live
if [ ! -d "${scriptdir}" ]; then
   echo
   echo " You don't have a "${scriptdir}" directory.  Creating now."
   mkdir "${scriptdir}"
   cd "${scriptdir}"
   get_location
fi
# The Documents dir where the test results and user guide go
if [ ! -d "${docdir}" ]; then
   echo
   echo " You don't have a "${docdir}" directory.  Creating now."
   mkdir "${docdir}"
   cd "${docdir}"
   #get_location
fi

   #echo " Going back to the temporary directory"
   cd ${tmpextract}
   get_location

# Compare iamhere with tmpextract
if [ "${iamhere}" == "${tmpextract}" ]; then
   echo
   echo "  We're in the right place"
   echo
   ### THD --- test for ~/bin ioztst.sh and go thru the else loop
   # If either the tarfile (in tmpextract) or scriptfile (in HOME/bin)
   # This must be a new install so do the first bit
   if [ ! -f "${tarfile}" ] && [ ! -f "${scriptfile}" ]; then
      echo "  Copying ${tarfile} to ${tmpextract}"
      cp "${downloaddir}/${tarfile}" "${tmpextract}"
      tar xf "${tarfile}"
      echo
      chmod +x ioztst.sh
      echo
   else
      echo "  Files exist, probably from an earlier install"
      if [ ! -d "${tmpextract}/oldver" ]; then
         mkdir "${tmpextract}/oldver"
      fi
      cd "${tmpextract}"
      get_location
      # is the tmpextract dir empty
      notempty=`ls | wc -l`
      if [ ${notempty} -gt 2 ]; then
         oldfiles=`ls -A | grep -v oldver`
         for i in $oldfiles ; do
            #echo "  File: $i"
            mv $i oldver
            cp "${downloaddir}/${tarfile}" "${tmpextract}"
            tar xf "${tarfile}"
         done
      else
         echo "  Checking if an upgrade is possible"
         cp "${downloaddir}/${tarfile}" "${tmpextract}"
         tar xf "${tarfile}"
      echo
      fi
      # Time to see if this is a later version and we can allow upgrade
      is_this_an_upgrade
      # changever is not a misspelling [change ver]
      if [ "${changever}" == "true" ]; then
         # It's possible to upgade, ask user
         echo
         read -p "  Do you want to upgrade to the new version now [$newver] (y/n): " ans
         answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
         if [ "${answer}" == "y" ]; then
            echo
            echo "  Your original iozconf will be saved as iozconf.backup"
            echo "  Each time you run the config script, the iozconf backup file"
            echo "  will be overwritten, so be careful! (located in: ${configdir}"
            echo
            ans=""
            read -p "  Are you sure you want to upgrade to the new version now [$newver] (y/n): " ans
            answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
            if [ "${answer}" == "y" ]; then
               echo "  Starting upgrade now..."
               echo "  Editing iozconf to insert your currently defined basedir parameter"
               get_host_config
               echo "  Copying new ioztst.sh script to your ${scriptdir} directory"
               cp ${tmpextract}/ioztst.sh "${scriptdir}"
               echo "  Copying the userguide to ${docdir}"
               cp ${tmpextract}/zfstst_user_guide.txt ${docdir}
            fi
         else
            echo "  You can upgrade later, just run the Install.sh script again"
         fi
      fi
   fi
else
   get_location
   echo " Something went wrong should be in ${scriptdir} but we're in ${iamhere}"
   echo " >> Aborting install"
fi

# The base directory hierarchy for the config and saved ioztst.sh starts here
if [ ! -d "${configdir}" ] ; then
    echo "  Creating directory for config file"
    mkdir "${configdir}"
    #ls -d "${configdir}"
fi

# The directory that throughput and auto ioztst.sh files are saved
if [ ! -d "${Tputdir}" ] ; then
    echo "  Creating directory for throughput tests"
    mkdir "${Tputdir}"
    #ls -d "${Tputdir}"
fi

# The directory where the Default throughput and Auto test files go
# There can be only one (of each type)
if [ ! -d "${Autodir}" ] ; then
    echo "  Creating directory for Default (Auto) tests"
    mkdir "${Autodir}"
    #ls -d "${Autodir}"
fi

cd ~/bin
# -------------------------------------------------------------------
#  Probably the last thing to do after everything is installed
# Read in the variables from the config file
if [ -f "${configdir}/${configfile}" ]; then
   # This is not a first time installation
   #use the existing config file
   source "${configdir}/${configfile}"
else
   # First time install copy and edit the conf fike
   source "${tmpextract}/${configfile}"
fi

#  Check to ensure that basedir is set in $HOME/.config/ioztst/iozconf
if [ ! -d "${basedir}/" ]; then
   #clear
   echo
   echo "  >>> The \$basedir variable is not yet set for your system:"
   echo
   echo "  basedir=[${basedir}]  << Look for this in the file and edit it"
   echo "    In the line above, the space between the brackets"
   echo "    should not be empty. it should show the path to the"
   echo "    directory on the drive/array where you want to do the testing"
   echo "  Please set this variable in the config file before proceding"
   echo "  The config file is: $HOME/.config/ioztst/iozconf"
   echo "  Use the examples to guide your Basedir variable entry"
   echo "  In it's simplest form your \$basedir could be \$basedir=\$HOME"
   echo
   echo "  Two environment variables are commonly used in these bash scripts:"
   echo "  \$USER, an alias for yuur username, [$USER] and \$HOME, your"
   echo "  [$HOME] directory.  These can be and are used as variables."
   echo
   echo "  <<< IMPORTANT: do NOT append a '/' to the end of the basedir."
   echo
   echo "  You can use the 'nano' editor to edit your basedir variable."
   echo "  Open a file browser and decide on the location to do your tests."
   echo "  It should be the root of a drive that is preferably not an SSD"
   echo "  or a USB stick. Not an SSD so you don't risk wearing it out.  USB"
   echo "  stick because it's too small, also these have a high wear rate."
   echo "  The basedir can be your \$HOME directory If you have a HDD (not an"
   echo "  SSD). This script will create a 'tmptest' directory below the"
   echo "  basedir directory you enter into the config file. to use your"
   echo "  home directory [$HOME], enter the value \$HOME for the basedir."
   echo
   echo " You may edit the basedir directly from within this script."
   echo " Please decide on a basedir before editing the config file."
   echo
   echo "  Do you want to edit the config file now (y/n)  <Ctrl>C to exit"
   read -p "  If you do, <Ctrl><O> <Enter> writes the file out, <Ctrl><X> exits the editor: " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      # Do not edit the config file in the tempextract directory
      echo
      echo " Copying ${tmpextract}/${configfile} to ${configdir}"
      cp "${tmpextract}/${configfile}" "${configdir}"
      # Instead edit the config file in the configdir directory
      nano "${configdir}/${configfile}"
      # Read in the edited config file
      source "${configdir}/${configfile}"
      echo
      chmod +x ${tmpextract}/ioztst.sh
      cp ${tmpextract}/ioztst.sh "${scriptdir}"
   else
      echo
      echo "  You must edit the config file before running the ioztst.sh script"
      cp "${tmpextract}/${configfile}" "${configdir}"
      source "${configdir}/${configfile}"
      echo
   fi
   read -p "  >>> Press <Enter> to continue" z
   #exit 1
fi

# Create the testing directory
if [ -d "${basedir}" ] ; then
   cd "${basedir}"
   get_location
   if [ ! -d "${targetdir}" ] ; then
      echo "  Making test directory targetdir: ${targetdir}"
      mkdir "${targetdir}"
   fi
fi
show_dirs


# EOF
