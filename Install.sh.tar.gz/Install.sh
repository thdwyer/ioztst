#!/bin/bash

##########
#
# Project     : iozone shell script wrapper install script
# Version     : ver 0.2.5
# Started     : Wed 31 Jul 2024
# Author      : Terry Dwyer
# Module      :
# Purpose     : Install and setup the iozone utility.
#             :
#             :
# Description :
#
##########

# start of code here

###########################################################################
# Do not edit anything in this script unless you know what you are doing. #
# changing the wrong variables could result in loss of your data.         #
###########################################################################

clear

dontclear=true
enableiozone=YES
basedir=""

testdir=tmptest
targetdir=$basedir/$testdir

#  Values needed:
# Temporary dir to extract the files from the archive
tmpextract=$HOME/tempiozextract
# Hopefully the downloaded package is in the default Downloads directory
downloaddir=$HOME/Downloads
# This takes into account version changes
tarfile=`ls ${downloaddir}/ioztst* | awk -F"/" '{print $NF}'`
# Where the results from the test and the user guide go
docdir=$HOME/Documents
#  Install dir for ioztst.sh
scriptdir=$HOME/bin
#  Dir to store config file and scripts to run iozone
configbasedir=$HOME/.config
#  Config basedir
configdir=$HOME/.config/ioztst
# Config file
configfile=iozconf
#   Dir to save results files in
#  Throughput definition fies
Tputdir=$HOME/.config/ioztst/Run
#  Auto definition files
Autodir=$HOME/.config/ioztst/Default

# Set a few things up
shopt -s nullglob
# Error trapping
#set -Eeou pipefail

# Get the name of the running script
iam=$(basename $(readlink -nf $0))
# Get the version of this script from the header
version=`grep "^# Version" ${iam} | awk '{print $NF}'`

export TIME="\t%E real,\t%U user,\t%S sys"
timecmd=/usr/bin/time
# Replaces all spaces in the returned date value with underscores
datevar=`date | sed '{s/ /_/g}'`
echo
echo "  iozone shell script wrapper install script: Version ${version}"
echo

# Define any necessary or useful functions:

trap 'error_handler $? $LINENO' ERR
error_handler() {
   echo "Error: ($1) occurred on $2"
}

function get_location {
   iamhere=`pwd` ; echo "  PWD: ${iamhere}"
}

function show_dirs {
   if [ "${dontclear}" != "true" ]; then
      clear
   fi
   echo
   echo " -----------------------------------------------------------------------------------"
   echo " |                            <<< Ver: ${version} >>>                                     |"
   echo " -----------------------------------------------------------------------------------"
   echo " |           Complete list of directory and files from your variables              |"
   echo " -----------------------------------------------------------------------------------"
   echo " |         Description          |  variable name  |         Variable data          |"
   echo " -----------------------------------------------------------------------------------"
   echo "------------------------------------------------------------------------------------"
   echo "                    Run iozone:   enableiozone      ${enableiozone}"
   echo "------------------------------------------------------------------------------------"
   echo "                       Basedir:   basedir           ${basedir}"
   echo "                       Testdir:   testdir           ${testdir}"
   echo "                     Targetdir:   targetdir         ${targetdir}"
   echo "                     Resultdir:   resultdir         ${resultdir}"
   echo "                    Resultfile:   resultfile        ${resultfile}"
   echo "           Screen Capture file:   scrncapfile       ${scrncapfile}"
   echo "                   Result file:   result            ${result}"
   echo "           Screen Capture file:   scrncap           ${scrncap}"
   echo "                   Config file:   configfile        ${configdir}/${configfile}"
   echo " -----------------------------------------------------------------------------------"
   echo "            Saved Test Basedir:   savedtestbasedir  ${savedtestbasedir}"
   echo "            Saved This Run dir:   savedrun          ${savedrun}"
   echo "             Saved Default dir:   saveddefaults     ${saveddefaults}"
   echo "      Saved This Run Auto file:   Asaverunfile      ${Asaverunfile}"
   echo "      Saved This Run Tput file:   Tsaverunfile      ${Tsaverunfile}"
   echo "       Saved Default Auto file:   Asavedefaultfile  ${Asavedefaultfile}"
   echo "       Saved Default Tput file:   Tsavedefaultfile  ${Tsavedefaultfile}"
   echo " -----------------------------------------------------------------------------------"
   echo
   #exit 1
}

# Start checking for and creating directories where necessary
if [ ! -d "${tmpextract}" ]; then
   echo
   echo " You don't have a ${tmpextract} directory.  Creating now."
   mkdir "${tmpextract}"
   cd "${tmpextract}"
   get_location
fi

# First is the $HOME/bin dir where the script will live
if [ ! -d "${scriptdir}" ]; then
   echo
   echo " You don't have a "${scriptdir}" directory.  Creating now."
   mkdir "${scriptdir}"
   cd "${scriptdir}"
   get_location
fi
# The Documents dir where the test results and user guide go
if [ ! -d "${docdir}" ]; then
   echo
   echo " You don't have a "${docdir}" directory.  Creating now."
   mkdir "${docdir}"
   cd "${docdir}"
   get_location
fi

   echo " Going back to the temporary directory"
   cd "${tmpextract}"
   get_location

# Compare iamhere with tmpextract
if [ "${iamhere}" == "${tmpextract}" ]; then
   echo
   echo "  We're in the right place"
   echo
   if [ ! -f "${tarfile}" ]; then
      echo "  Copying ${tarfile} to ${tmpextract}"
      cp "${downloaddir}/${tarfile}" "${tmpextract}"
      echo "  Extracting files from package into ${iamhere}"
      tar xf "${tarfile}"
      echo
      echo "  Making ioztst.sh executable by owner"
      chmod +x ioztst.sh
      echo
      echo "  Moving ioztst.sh to ${scriptdir}"
      mv ./ioztst.sh "${scriptdir}"
      echo
   else
      echo " The files have already been extracted and copied"
      echo
   fi
   #get_location
else
   get_location
   echo " Something went wrong should be in ${scriptdir} but we're in ${iamhere}"
   echo " >> Aborting install"
fi

# The base directory hierarchy for the config and saved ioztst.sh starts here
if [ ! -d "${configdir}" ] ; then
    echo "  Creating directory for config file"
    mkdir "${configdir}"
    #ls -d "${configdir}"
fi

# The directory that throughput and auto ioztst.sh files are saved
if [ ! -d "${Tputdir}" ] ; then
    echo "  Creating directory for throughput tests"
    mkdir "${Tputdir}"
    #ls -d "${Tputdir}"
fi

# The directory where the Default throughput and Auto test files go
# There can be only one (of each type)
if [ ! -d "${Autodir}" ] ; then
    echo "  Creating directory for Default (Auto) tests"
    mkdir "${Autodir}"
    #ls -d "${Autodir}"
fi

#-------------
cd ~/bin
#get_location

# -------------------------------------------------------------------
#  Probably the last thing to do after everything is installed
# Read in the variables from the config file
source "${tmpextract}/${configfile}"

#  Check to ensure that basedir is set in $HOME/.config/ioztst/iozconf
if [ ! -d "${basedir}/" ]; then
   clear
   echo
   echo "  >>> The \$basedir variable is not yet set for your system:"
   echo
   echo "  basedir=[${basedir}]  << Look for this in the file and edit it"
   echo "    In the line above, the space between the brackets"
   echo "    should not be empty. it should show the path to the"
   echo "    directory on the drive/array where you want to do the testing"
   echo "  Please set this variable in the config file before proceding"
   echo "  The config file is: $HOME/.config/ioztst/iozconf"
   echo "  Use the examples to guide your Basedir variable entry"
   echo "  In it's simplest form your \$basedir could be \$basedir=\$HOME"
   echo
   echo "  Two environment variables are commonly used in these bash scripts:"
   echo "  \$USER, an alias for yur username, [$USER] and \$HOME, your"
   echo "  [$HOME] directory.  These can be and are used as variables."
   echo
   echo "  <<< IMPORTANT: do NOT append a '/' to the end of the basedir."
   echo
   echo "  You can use the 'nano' editor to edit your basedir variable."
   echo "  Open a file browser and decide on the location to do your tests."
   echo "  It should be the root of a drive that is preferably not an SSD"
   echo "  or a USB stick. Not an SSD so you don't risk wearing it out.  USB"
   echo "  stick because it's too small, also these have a high wear rate."
   echo "  The basedir can be your \$HOME directory If you have a HDD (not an"
   echo "  SSD). This script will create a 'tmptest' directory below the"
   echo "  basedir directory you enter into the config file. to use your"
   echo "  home directory [$HOME], enter the value \$HOME for the basedir."
   echo
   echo " You may edit the basedir directly from within this script."
   echo " Please decide on a basedir before editing the config file."
   echo
   echo "  Do you want to edit the config file now (y/n)  <Ctrl>C to exit"
   read -p "  If you do, <Ctrl><O> <Enter> writes the file out, <Ctrl><X> exits the editor: " ans
   answer=`echo "${ans}" | tr "[:upper:]" "[:lower:]"`
   if [ "${answer}" == "y" ]; then
      nano "${tmpextract}/${configfile}"
   echo
   echo " Copying ${tmpextract}/${configfile} to ${configdir}"
   cp "${tmpextract}/${configfile}" "${configdir}"
   source "${configdir}/${configfile}"
   echo
   else
      echo
      echo "  You must edit the config file before running the ioztst.sh script"
      cp "${tmpextract}/${configfile}" "${configdir}"
      source "${configdir}/${configfile}"
      echo
   fi
   read -p "  >>> Press <Enter> to continue" z
   exit 1
fi

# Create the testing directory
if [ -d "${basedir}" ] ; then
   echo " Basedir: ${basedir} exists"
   #echo " Targetdir: ${targetdir}"
   cd "${basedir}"
   get_location
   if [ ! -d "${targetdir}" ] ; then
      echo "  Making test directory targetdir: ${targetdir}"
      mkdir "${targetdir}"
   else
      echo " Targetdir: ${targetdir} already exists"
   fi
fi
show_dirs


# EOF
